/* browse button */
$(document).ready(function() {
    $('.btn').on('click', function() {
      $('.file').trigger('click');
    });
    $('.file').on('change', function() {
      var fileName = $(this)[0].files[0].name;    
      $('#file-name').val(fileName);
    });
  })

/* Select Multiple on step 3,4,etc */

var json1 = [{
  id: 'select_all',
  name: 'Select All',
},
{
  id: '1',
  name: 'First Item',
},
{
  id: '2',
  name: 'Second Item',
},
{
  id: '3',
  name: 'Third Item',
},


]; 
  var list = [1,2,3,4,5,6,7,8,9,10]
  $('#demo').dropdown({
    data: json1,
    limitCount: 40,
    multipleMode: 'label',
    choice: function () {
      // console.log(arguments,this);
    }
  });    
  function submit(){
    var foo = $('#data').val(); 
    console.log('mutliple',foo);
  }
  

  /* Select Multiple on step 3,4,etc */

  /* Select All */

//   $('#select_all').click(function() {
//     $('#data dropdown-display-label').prop('selected', true);
//  });
$("#data").each(function() {
  $("select:not([size])")
});

  /* Select All */