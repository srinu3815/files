from flask import Flask, app, render_template, request, send_file
# from flask.helpers import url_for
from werkzeug.utils import secure_filename
from flask import jsonify
# import pymysql 
# pymysql.install_as_MySQLdb()
from flask import Flask, render_template, redirect, request, flash
#from flask_mysqldb import MySQL,MySQLdb #pip install flask-mysqldb https://github.com/alexferl/flask-mysqldb% brew install mysql-client
# from werkzeug.utils import secure_filename
# import os
# import base64
#import magic
# import urllib.request
# from werkzeug.utils import secure_filename
# from datetime import datetime
# import numpy as np
# import pandas as pd
# import csv

# import connexion
# connexion_app = connexion.App(__name__)
# This gets the underlying Flask app instance.
# flask_app = connexion_app.app  # Flask(__name__)
# app.secret_key = "satjusn321"
# app.config['MYSQL_HOST'] = 'localhost'
# app.config['MYSQL_USER'] = 'root'
# app.config['MYSQL_PASSWORD'] = 'P9010990553B'
# app.config['MYSQL_DB'] = 'procurementdata'
# app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
# mysql = MySQL(app)

# This creates the connexion application instance.
from flask import Flask, request, render_template, jsonify # Import flask libraries
# import pickle
app = Flask(__name__,template_folder="templates")

@app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('step-4.html')

    
    
if __name__=="__main__":
    app.run(debug=True,port=9460)
    


