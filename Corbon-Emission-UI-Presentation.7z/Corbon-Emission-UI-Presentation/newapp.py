from flask import Flask, render_template, request, send_file
from flask.helpers import url_for
from werkzeug.utils import secure_filename
from flask import jsonify
import pymysql 
pymysql.install_as_MySQLdb()
from flask import Flask, render_template, redirect, request, flash
from flask_mysqldb import MySQL,MySQLdb #pip install flask-mysqldb https://github.com/alexferl/flask-mysqldb% brew install mysql-client
from werkzeug.utils import secure_filename
import os
import base64
import magic
import urllib.request
from werkzeug.utils import secure_filename
from datetime import datetime
import csv
import pandas as pd
import numpy as np

from flask_mysqldb import MySQL,MySQLdb #pip install flask-mysqldb https://github.com/alexferl/flask-mysqldb% brew install mysql-client



app = Flask(__name__)

app.secret_key = "satjusn321" 
app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = 'P9010990553B'
app.config['MYSQL_DB'] = 'carbonemission'
app.config['MYSQL_CURSORCLASS'] = 'DictCursor'
mysql = MySQL(app)
@app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('index.html',rows='')

@app.route('/upload', methods=['POST'])

def upload(): 
    
    uploaded_file = request.files['file']
    print('uploaded')
    if uploaded_file.filename != '':
        df=pd.read_excel(uploaded_file)

        csv_data=df.fillna(0)
    

    
        length=dbupload1(csv_data)
        return render_template("emission-factor.html",rows=length)
    



@app.route('/upload2', methods=['POST'])

def upload2(): 
    
    uploaded_file = request.files['file']
    print('uploaded')
    if uploaded_file.filename != '':
        df=pd.read_excel(uploaded_file)

        csv_data=df.fillna(0)
        length=dbupload2(csv_data)
        return render_template("step-3.html",rows=length)


        #return redirect(url_for('screen3',rows=length))


def dbupload2(csv_data):


    cursor = mysql.connection.cursor()
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    vals=csv_data.values.tolist()
    query = """INSERT INTO defradata  (EFCategory,EF,Years) VALUES (%s,%s,%s)"""
    cursor.executemany(query,vals)
    mysql.connection.commit()
    cur.close()
    return len(csv_data)

def dbupload1(csv_data):
    cursor = mysql.connection.cursor()
    cur = mysql.connection.cursor(MySQLdb.cursors.DictCursor)
    vals=csv_data.values.tolist()
    query = """INSERT INTO procurmentdata  (VendorNameLevel1 ,Region,Country,Level0CategorySpend,Level1CategorySpend,Level2CategorySpend,SpendinEuro,years) VALUES (%s,%s,%s,%s,%s,%s,%s,%s)"""
    cursor.executemany(query,vals)
    mysql.connection.commit()
    cur.close()
    return len(csv_data)


app.run(debug=True,port=9058)