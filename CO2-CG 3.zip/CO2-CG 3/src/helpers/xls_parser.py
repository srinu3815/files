from flask.helpers import flash
from werkzeug.exceptions import HTTPException
import pandas as pd


def xls_parser(input_file):#uploaded files (read data from uploaded excel files)
    try:
        df = pd.read_excel(input_file, index_col=None)
        df = df.rename(columns=lambda x: x.strip())
        df.columns = [x.lower() for x in df.columns]
        return df
    except Exception as e:
        print(e)
        flash("Unable to parse xls file.", "isa_error")
        raise HTTPException
