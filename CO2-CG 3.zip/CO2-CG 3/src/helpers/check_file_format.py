#accepted file extension
file_MIME_types = {'xls': ["application/vnd.ms-excel", 
                           "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                           "application/vnd.openxmlformats-officedocument.spreadsheetml.template",
                           "application/vnd.ms-excel.sheet.macroEnabled.12",
                           "application/vnd.ms-excel.template.macroEnabled.12",
                           "application/vnd.ms-excel.addin.macroEnabled.12",
                           "application/vnd.ms-excel.sheet.binary.macroEnabled.12"
                           ]}

#check file extension
def check_file_format(required_format, input_file):
    return input_file.content_type in file_MIME_types[required_format]