from flask import flash
from numpy import ogrid
from pandas.core.indexes import category
from sqlalchemy.orm.session import Session
from ..db import db
from sqlalchemy.orm import sessionmaker

#table properties for defra
class DefraData(db.Model):
    __tablename__ = 'DefraData'
    __table_args__ = {'extend_existing': True}
    id = db.Column(db.Integer, primary_key=True)
    ef_category = db.Column(db.String(225) )
    ef_value = db.Column(db.Float)
    year = db.Column(db.Integer)
    
    @staticmethod
    def create_object(data_dict):
        if type(data_dict["ef value"]) == type(" "):
            data_dict["ef value"] = 0.0

        if type(data_dict["year"]) == type(" "):
            data_dict["year"] = 0
            
        return DefraData(ef_category = data_dict["ef category"],
                         ef_value = data_dict["ef value"],
                         year = data_dict["year"]
                        )

    @classmethod #upload defra to db
    def save_data_to_table(cls, input_df):
        engine = db.get_engine()
        Session = sessionmaker(bind=engine)
        session = Session()
        try:
            data = [DefraData.create_object(i) for i in input_df.to_dict(orient='records')]
            session.add_all(data)
            session.commit()
            session.close()
            flash("Data upload successful. {} rows effected.".format(len(data)), "isa_success")
        except Exception as e:
            session.rollback()
            session.close()
            flash("Error uploading to database", "isa_error")
            print(e)