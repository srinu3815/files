from re import I, S
from ..models.Procurement import ProcurementData
from ..db import db
import pandas as pd
import io
from flask import send_file

#in memory bite file object 

def download_proc_data():#download mapped files or proc data in screen 3,4
    conn = db.get_engine()
    df = pd.read_sql_table('ProcurementData', conn)
    df = df.drop('id', axis=1)
    s_buf = io.BytesIO()
    df.to_excel(s_buf, index=False)
    s_buf.seek(0)
    return send_file(s_buf, attachment_filename="Mapped-Data.xlsx", as_attachment=True)