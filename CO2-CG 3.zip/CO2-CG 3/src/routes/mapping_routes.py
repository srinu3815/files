from flask import Blueprint, json, render_template, flash, redirect, url_for
from ..controller.filter import get_suppliers_list
from ..controller.filter import get_efcategory_list
from ..controller.filter import get_level_0_category
from ..controller.filter import get_level_1_category
from ..controller.filter import get_level_2_category
from ..controller.filter import get_proc_year
from ..controller.filter import get_filter_proc_level0
from ..controller.filter import get_filter_proc_level1
from ..controller.filter import get_filter_proc_level2
from ..controller.filter import get_filter_proc_year
from ..controller.download_file import download_proc_data
from ..controller.apply_ef_mapping import apply_ef_mapping
from ..controller.apply_ef_mapping import apply_ef_mapping_from_file
from ..controller.apply_exclusion_rules import apply_exclusion_rules
from ..controller.apply_exclusion_rules import apply_exclusion_mapping_from_file
from ..models.DefraData import DefraData
from ..models.Procurement import ProcurementData

from flask import jsonify, request 


mapping_routes = Blueprint('mapping_routes', __name__,
                        template_folder='templates',
                        static_folder='../public',
                        static_url_path='/public')


@mapping_routes.route('/mapping/suppplier-ef-data')
def mapping_ef_data():
    return render_template('mapping-ef-data.html')#screen3 


@mapping_routes.route('/mapping/suppplier-ef-data', methods=["POST"])#
def post_mapping_ef_data():
    if request.args.get('formNum') == '1':
        try:
            apply_ef_mapping(request.form)
        except Exception as e:
            return render_template('mapping-ef-data.html')
    else:
        if request.files['xlsFile'].filename == "":
            flash("Please select the mapping file.", "isa_error")
            return redirect(url_for('mapping_routes.mapping_ef_data'))
        else:
            try:
                apply_ef_mapping_from_file(request.files['xlsFile'])
                return redirect(url_for('mapping_routes.mapping_exclusion_rules'))
            except Exception as e:
                print(e)
                return redirect(url_for('mapping_routes.mapping_ef_data'))
    return redirect(url_for('mapping_routes.mapping_exclusion_rules'))


@mapping_routes.route('/mapping/exclusion-rules')
def mapping_exclusion_rules():
    return render_template('mapping-exclusion-rules.html')


@mapping_routes.route('/mapping/exclusion-rules', methods=["POST"])
def post_mapping_exclusion_rules():
    if request.args.get('formNum') == '1':
        try:
            apply_exclusion_rules(request.form)
        except Exception as e:
            return render_template('mapping-ef-data.html')
    else:
        if request.files['xlsFile'].filename == "":
            flash("Please select the mapping file.", "isa_error")
            return redirect(url_for('mapping_routes.mapping_exclusion_rules'))
        else:
            try:
                apply_exclusion_mapping_from_file(request.files['xlsFile'])
                return redirect(url_for('mapping_routes.mapping_exclusion_rules'))
            except Exception as e:
                print(e)
                return redirect(url_for('mapping_routes.mapping_exclusion_rules'))  
    return redirect(url_for('mapping_routes.mapping_exclusion_rules'))




@mapping_routes.route('/mapping/download')
def download_data():
   return download_proc_data()


@mapping_routes.route('/mapping/filter/defra/rows_avail')
def is_defra_available():
    res = list(DefraData.query.filter().all())
    if len(res) == 0:
        return jsonify({"status": False,"n_rows": len(res)})
    else:
        return jsonify({"status": True,"n_rows": len(res)})



@mapping_routes.route('/mapping/filter/proc/rows_avail')
def no_of_rows():
    res = list(ProcurementData.query.filter().all())
    return jsonify({"status": True,"n_rows": len(res)})




@mapping_routes.route('/mapping/filter/suppliers')
def filter_data1():
   return jsonify(get_suppliers_list())


@mapping_routes.route('/mapping/filter/level0', methods=["POST"])
def filter_level0():
    return jsonify(get_level_0_category(request.form.getlist('data[]')))


@mapping_routes.route('/mapping/filter/level1', methods=["POST"])
def filter_level1():
    supplier_data = request.form.getlist('supplierData[]')
    level_0_data = request.form.getlist('level0Data[]')
    return jsonify(get_level_1_category(supplier_data, level_0_data))


@mapping_routes.route('/mapping/filter/level2', methods=["POST"])
def filter_level2():
    supplier_data = request.form.getlist('supplierData[]')
    level_0_data = request.form.getlist('level0Data[]')
    level_1_data = request.form.getlist('level1Data[]')
    return jsonify(get_level_2_category(supplier_data, level_0_data, level_1_data))


@mapping_routes.route('/mapping/filter/year', methods=["POST"])
def filter_proc_year():
    supplier_data = request.form.getlist('supplierData[]')
    level_0_data = request.form.getlist('level0Data[]')
    level_1_data = request.form.getlist('level1Data[]')
    level_2_data = request.form.getlist('level2Data[]')
    return jsonify(get_proc_year(supplier_data, level_0_data, level_1_data, level_2_data))


@mapping_routes.route('/mapping/filter/efcategory')
def filter_efcategory():
    return jsonify(get_efcategory_list())


@mapping_routes.route('/mapping/filter/proc/level0')
def filter_proc_level0():
    return jsonify(get_filter_proc_level0())


@mapping_routes.route('/mapping/filter/proc/level1', methods=["POST"])
def filter_proc_level1():
    level_0_data = request.form.getlist('level0Data[]')
    return jsonify(get_filter_proc_level1(level_0_data))


@mapping_routes.route('/mapping/filter/proc/level2', methods=["POST"])
def filter_proc_level2():
    level_0_data = request.form.getlist('level0Data[]')
    level_1_data = request.form.getlist('level1Data[]')
    return jsonify(get_filter_proc_level2(level_0_data, level_1_data))


@mapping_routes.route('/mapping/filter/proc/year', methods=["POST"])
def filter_proc_year2():
    level_0_data = request.form.getlist('level0Data[]')
    level_1_data = request.form.getlist('level1Data[]')
    level_2_data = request.form.getlist('level2Data[]')
    return jsonify(get_filter_proc_year(level_0_data, level_1_data, level_2_data))