from flask import Blueprint, render_template, abort, flash, request, redirect
from flask.helpers import url_for
from jinja2 import TemplateNotFound
from sqlalchemy.engine import url
from ..controller.upload_procurement_file import save_procurement_file
from ..controller.upload_ef_data_file import save_ef_data_file

upload_routes = Blueprint('upload_routes', __name__,
                        template_folder='templates',
                        static_folder='../public',
                        static_url_path='/public')

#data capturing for proc and defra

@upload_routes.route('/upload/procurement-spent-data')
def upload_procurement_data():
    return render_template('upload-pages/procurement-spent-data.html')


@upload_routes.route('/upload/procurement-spent-data', methods=['POST'])
def post_upload_procurement_data():
    if request.files['xlsFile'].filename == "":
        flash("Please upload the procurement data file.", "isa_error")
        return redirect(url_for('upload_routes.upload_procurement_data'))
    else:
        try:
            save_procurement_file(request.files['xlsFile'])
            return redirect(url_for('upload_routes.upload_ef_data'))
        except Exception as e:
            print(e)
            return redirect(url_for('upload_routes.upload_procurement_data'))

#defra data routes start here
@upload_routes.route('/upload/ef-data')
def upload_ef_data():
    if request.args.get('skip') == '1':
        flash("DEFRA data file skipped. 0 rows effected.", "isa_warning")
        return redirect(url_for('mapping_routes.mapping_ef_data'))
    return render_template('upload-pages/ef-data.html')

#save defra to db
@upload_routes.route('/upload/ef-data', methods=['POST'])
def post_ef_data():
    if request.files['xlsFile'].filename == "":
        flash("Please select the DEFRA data file.", "isa_error")
        return redirect(url_for('upload_routes.upload_ef_data'))
    else:
        try:
            save_ef_data_file(request.files['xlsFile'])
            return redirect(url_for('mapping_routes.mapping_ef_data'))
        except Exception as e:
            print(e)
            return redirect(url_for('upload_routes.upload_procurement_data'))
