
# CREATE USER 'pythonapp'@'localhost' IDENTIFIED BY 'password';
# GRANT CREATE, ALTER, DROP, INSERT, UPDATE, DELETE, SELECT, REFERENCES, RELOAD on *.* TO 'pythonapp'@'localhost' WITH GRANT OPTION;

import mysql.connector

mydb = mysql.connector.connect(
  host="localhost",
  port="3308",
  user="pythonapp",
  password="password"
)