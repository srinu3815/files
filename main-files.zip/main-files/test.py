
# CREATE USER 'pythonapp'@'localhost' IDENTIFIED BY 'password';
# GRANT CREATE, ALTER, DROP, INSERT, UPDATE, DELETE, SELECT, REFERENCES, RELOAD on *.* TO 'pythonapp'@'localhost' WITH GRANT OPTION;

import mysql.connector

mydb = mysql.connector.connect(host="192.168.0.2",port="3306",user="root",password="P9010990553B")