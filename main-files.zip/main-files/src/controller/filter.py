from operator import le
from ..models.Procurement import ProcurementData
from ..models.DefraData import DefraData
import json

#screen3 starts here
def get_suppliers_list():
    query = ProcurementData.query.distinct().values(ProcurementData.vendor_name)
    data = [{"id": val[0], "text": val[0]} for i, val in enumerate(query)]
    return json.dumps(data)


def get_efcategory_list():
    query = DefraData.query.distinct().values(DefraData.ef_category)
    data = [{"id": val[0], "text": val[0]} for i, val in enumerate(query)]
    return json.dumps(data)


def get_level_0_category(suppliers):
    query = ProcurementData.query.filter(ProcurementData.vendor_name.in_(suppliers)).distinct().values(ProcurementData.level_0_category)
    data = [{"id": val[0], "text": val[0]} for i, val in enumerate(query)]
    return json.dumps(data)

def get_level_1_category(suppliers, level0):
    query1 = ProcurementData.query.filter(ProcurementData.vendor_name.in_(suppliers)).distinct()
    query2 = query1.filter(ProcurementData.level_0_category.in_(level0)).distinct().values(ProcurementData.level_1_category)
    data = [{"id": val[0], "text": val[0]} for i, val in enumerate(query2)]
    return json.dumps(data)

def get_level_2_category(suppliers, level0, level1):
    query1 = ProcurementData.query.filter(ProcurementData.vendor_name.in_(suppliers)).distinct()
    query2 = query1.filter(ProcurementData.level_0_category.in_(level0)).distinct()
    query3 = query2.filter(ProcurementData.level_1_category.in_(level1)).distinct().values(ProcurementData.level_2_category)
    data = [{"id": val[0], "text": val[0]} for i, val in enumerate(query3)]
    return json.dumps(data)


def get_proc_year(suppliers, level0, level1, level2):
    query1 = ProcurementData.query.filter(ProcurementData.vendor_name.in_(suppliers))
    query2 = query1.filter(ProcurementData.level_0_category.in_(level0))
    query3 = query2.filter(ProcurementData.level_1_category.in_(level1))
    query4 = query3.filter(ProcurementData.level_2_category.in_(level2)).distinct().values(ProcurementData.year)
    data = [{"id": val[0], "text": val[0]} for i, val in enumerate(query4)]
    return json.dumps(data)

#screen 4 filters starts here

def get_filter_proc_level0():
    query = ProcurementData.query.distinct().values(ProcurementData.level_0_category)
    data = [{"id": val[0], "text": val[0]} for i, val in enumerate(query)]
    return json.dumps(data)

def get_filter_proc_level1(level0):
    query1 = ProcurementData.query.filter(ProcurementData.level_0_category.in_(level0)).distinct().values(ProcurementData.level_1_category)
    data = [{"id": val[0], "text": val[0]} for i, val in enumerate(query1)]
    return json.dumps(data)


def get_filter_proc_level2(level0, level1):
    query1 = ProcurementData.query
    query2 = query1.filter(ProcurementData.level_0_category.in_(level0)).distinct()
    query3 = query2.filter(ProcurementData.level_1_category.in_(level1)).distinct().values(ProcurementData.level_2_category)
    data = [{"id": val[0], "text": val[0]} for i, val in enumerate(query3)]
    return json.dumps(data)


def get_filter_proc_year(level0, level1, level2):
    query1 = ProcurementData.query
    query2 = query1.filter(ProcurementData.level_0_category.in_(level0))
    query3 = query2.filter(ProcurementData.level_1_category.in_(level1))
    query4 = query3.filter(ProcurementData.level_2_category.in_(level2)).distinct().values(ProcurementData.year)
    data = [{"id": val[0], "text": val[0]} for i, val in enumerate(query4)]
    return json.dumps(data)
