from sqlalchemy.orm import query, sessionmaker
from werkzeug.exceptions import HTTPException
from ..db import db
from ..models.DefraData import DefraData
from ..models.Procurement import ProcurementData
from ..helpers.validate_columns_props import validate_exclusion_mapping_file_columns
from ..helpers.check_file_format import check_file_format
from ..helpers.xls_parser import xls_parser
from flask import flash


def apply_exclusion_rules(form):#handle filters form from 4th screen
    level0 = form.getlist('level0')
    level1 = form.getlist('level1')
    level2 = form.getlist('level2')
    year = form.get('year')
    ef_category = form.get('rule')

    if not(ef_category and level0 and level1 and level2 and year):
        flash("Error! Some form fields were empty", "isa_error")
        raise HTTPException

    query1 = ProcurementData.query
    query2 = query1.filter(ProcurementData.level_0_category.in_(level0))
    query3 = query2.filter(ProcurementData.level_1_category.in_(level1))
    query4 = query3.filter(ProcurementData.level_2_category.in_(level2))
    query5 = query4.filter(ProcurementData.year.in_([year]))

    records = list(query5)
    
    engine = db.get_engine()
    Session = sessionmaker(bind=engine)
    session = Session()
    try:
        for i in records:
            i.ef_category = ef_category
            i.ef_value = 0
            session.merge(i)
        session.commit()
        session.flush()
        flash("Rules applied successfully! {} rows effected".format(len(records)), "isa_success")      
    except Exception as e:
        flash("Error appliing rules! 0 rows effected", "isa_error")
        session.rollback()


def update_exclusion_mapping_data_in_db(xls_data):#store file data in db
    data = xls_data.to_dict(orient='records')
    effected_rows = 0

    engine = db.get_engine()
    Session = sessionmaker(bind=engine)
    session = Session()
    
    try:
        for i in data:
            query = ProcurementData.query.filter(ProcurementData.level_0_category==i['level 0 category'],
                                                 ProcurementData.level_1_category==i['level 1 category'],
                                                 ProcurementData.level_2_category==i['level 2 category']).all()
            rows = list(query)

            for j in rows:
                j.ef_category = i['ef category']
                j.ef_value = 0
                if type(j.ef_value) == type(" "):
                    j.ef_value = 0
                session.merge(j)
                effected_rows += 1
            session.commit()
            session.flush()
        flash("Mapping Successful! {} rows effected".format(effected_rows), "isa_success")
    except Exception as e:
        print(e)
        flash("Mapping Failed! Error uploading to database", "isa_error")
    
    return True


def apply_exclusion_mapping_from_file(input_file):#handle file submission form


    if not check_file_format('xls', input_file):
        flash("Please upload a valid Excel sheet.", "isa_error")
        raise HTTPException

    xls_data = xls_parser(input_file).drop_duplicates()
    validate_exclusion_mapping_file_columns(xls_data.columns)

    update_exclusion_mapping_data_in_db(xls_data)

    return True