from flask import render_template, url_for, flash
from werkzeug.exceptions import HTTPException
from ..helpers.check_file_format import check_file_format
from ..helpers.xls_parser import xls_parser
from ..helpers.validate_columns_props import validate_procurement_file_columns
from ..models.Procurement import ProcurementData

def save_procurement_file(input_file):#save proc file into db

    if not check_file_format('xls', input_file):
        flash("Please upload a valid Excel sheet.", "isa_error")
        raise HTTPException
    print("File format matched")
    xls_data = xls_parser(input_file)
    print("Parsing Completed")
    validate_procurement_file_columns(xls_data.columns)
    print("Validation COmplete")
    ProcurementData.save_data_to_table(xls_data)
    print("Saved to DB.")
    # print(xls_data.to_dict(orient='records'))
    
    return True