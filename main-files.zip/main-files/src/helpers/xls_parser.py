from flask.helpers import flash
from werkzeug.exceptions import HTTPException
import pandas as pd
import numpy as np


def xls_parser(input_file):#uploaded files (read data from uploaded excel files)
    try:
        df = pd.read_excel(input_file, index_col=None)
        df = df.rename(columns=lambda x: x.strip())
        df.columns = [x.lower() for x in df.columns]
        df = df.replace({np.nan: None})
        return df
    except Exception as e:
        print(e)
        flash("Unable to parse xls file.", "isa_error")
        raise HTTPException
