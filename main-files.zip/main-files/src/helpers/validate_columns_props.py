from flask.helpers import flash
from werkzeug.exceptions import HTTPException

#accepted columns
column_properties = {'procurement_data': 
                        { 'num_of_cols': 8,
                          'column_names': ["vendor name level 1", "region", "country", "level 0 category",
                                           "level 1 category", "level 2 category", "spent in euro", "year"
                                          ]
                        },
                      'ef_data': 
                        { 'num_of_cols': 3,
                          'column_names': ["ef category", "ef value", "year"]
                        },
                      'supp_ef_mapping_file': 
                        { 'num_of_cols': 6,
                          'column_names': ["level 0 category", "level 1 category", "level 2 category",
                           "ef category", "ef value", "year"]
                        },
                      'exclusion_mapping_file': 
                        { 'num_of_cols': 5,
                          'column_names': ["level 0 category", "level 1 category", "level 2 category",
                           "ef category", "year"]
                        }
                    }

#validate columns for proc
def validate_procurement_file_columns(input_column_list):
    if len(input_column_list) == column_properties['procurement_data']['num_of_cols']:
        for i in input_column_list:
          if i.lower() not in column_properties['procurement_data']['column_names']:
              flash("Invalid Column names! Please try again.", "isa_error")
              raise HTTPException
    else:
      flash("Invalid Columns! Please try again.", "isa_error")
      raise HTTPException

    return True


def validate_ef_file_columns(input_column_list):##validate columns for defra

    if len(input_column_list) == column_properties['ef_data']['num_of_cols']:
        for i in input_column_list:
          if i.lower() not in column_properties['ef_data']['column_names']:
              flash("Invalid Column names! Please try again.", "isa_error")
              raise HTTPException
    else:
      flash("Invalid Columns! Please try again.", "isa_error")
      raise HTTPException

    return True


def validate_supp_ef_mapping_file_columns(input_column_list):#validate columns for mapping file
    if len(input_column_list) == column_properties['supp_ef_mapping_file']['num_of_cols']:
        for i in input_column_list:
          if i.lower() not in column_properties['supp_ef_mapping_file']['column_names']:
              flash("Invalid Column names! Please try again.", "isa_error")
              raise HTTPException
    else:
      flash("Invalid Columns! Please try again.", "isa_error")
      raise HTTPException

    return True


def validate_exclusion_mapping_file_columns(input_column_list):#validate columns for exclusion mapping
    if len(input_column_list) == column_properties['exclusion_mapping_file']['num_of_cols']:
        for i in input_column_list:
          if i.lower() not in column_properties['exclusion_mapping_file']['column_names']:
              flash("Invalid Column names! Please try again.", "isa_error")
              raise HTTPException
    else:
      flash("Invalid Columns! Please try again.", "isa_error")
      raise HTTPException

    return True