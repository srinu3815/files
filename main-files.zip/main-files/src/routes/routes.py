from flask import Flask, app
from flask import Blueprint, render_template, abort
from jinja2 import TemplateNotFound

app_routes = Blueprint('app_routes', __name__,
                        template_folder='templates',
                        static_folder='../public',
                        static_url_path='/public')


# General Application Routes starts here
@app_routes.route('/', defaults={'page': 'upload-pages/procurement-spent-data'})
@app_routes.route('/<page>')
def show(page):
    try:
        return render_template('/{}.html'.format(page))
    except TemplateNotFound:
        abort(404)

