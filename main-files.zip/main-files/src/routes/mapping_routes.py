from flask import Blueprint, json, render_template, flash, redirect, url_for
from ..controller.filter import get_suppliers_list
from ..controller.filter import get_efcategory_list
from ..controller.filter import get_level_0_category
from ..controller.filter import get_level_1_category
from ..controller.filter import get_level_2_category
from ..controller.filter import get_proc_year
from ..controller.filter import get_filter_proc_level0
from ..controller.filter import get_filter_proc_level1
from ..controller.filter import get_filter_proc_level2
from ..controller.filter import get_filter_proc_year
from ..controller.download_file import download_proc_data
from ..controller.apply_ef_mapping import apply_ef_mapping
from ..controller.apply_ef_mapping import apply_ef_mapping_from_file
from ..controller.apply_exclusion_rules import apply_exclusion_rules
from ..controller.apply_exclusion_rules import apply_exclusion_mapping_from_file
from ..models.DefraData import DefraData
from ..models.Procurement import ProcurementData

from flask import jsonify, request 


mapping_routes = Blueprint('mapping_routes', __name__,
                        template_folder='templates',
                        static_folder='../public',
                        static_url_path='/public')


@mapping_routes.route('/mapping/suppplier-ef-data')
def mapping_ef_data():
    return render_template('mapping-ef-data.html')#screen3 


@mapping_routes.route('/mapping/suppplier-ef-data', methods=["POST"])#Upload screen3 file 
def post_mapping_ef_data():
    if request.args.get('formNum') == '1':
        try:
            apply_ef_mapping(request.form)
        except Exception as e:
            return render_template('mapping-ef-data.html')
    else:
        if request.files['xlsFile'].filename == "":
            flash("Please select the mapping file.", "isa_error")
            return redirect(url_for('mapping_routes.mapping_ef_data'))
        else:
            try:
                apply_ef_mapping_from_file(request.files['xlsFile'])
                return redirect(url_for('mapping_routes.mapping_ef_data'))
            except Exception as e:
                print(e)
                return redirect(url_for('mapping_routes.mapping_ef_data'))
    return redirect(url_for('mapping_routes.mapping_ef_data'))


@mapping_routes.route('/mapping/exclusion-rules')#screen 4 
def mapping_exclusion_rules():
    return render_template('mapping-exclusion-rules.html')


@mapping_routes.route('/mapping/exclusion-rules', methods=["POST"])#upload screen4 
def post_mapping_exclusion_rules():
    if request.args.get('formNum') == '1':
        try:
            apply_exclusion_rules(request.form)
        except Exception as e:
            return render_template('mapping-ef-data.html')
    else:
        if request.files['xlsFile'].filename == "":
            flash("Please select the mapping file.", "isa_error")
            return redirect(url_for('mapping_routes.mapping_exclusion_rules'))
        else:
            try:
                apply_exclusion_mapping_from_file(request.files['xlsFile'])
                return redirect(url_for('mapping_routes.mapping_exclusion_rules'))
            except Exception as e:
                print(e)
                return redirect(url_for('mapping_routes.mapping_exclusion_rules'))  
    return redirect(url_for('mapping_routes.mapping_exclusion_rules'))




@mapping_routes.route('/mapping/download')
def download_data():
   return download_proc_data()
