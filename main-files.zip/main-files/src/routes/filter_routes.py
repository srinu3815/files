from flask import Blueprint
from ..controller.filter import get_suppliers_list
from ..controller.filter import get_efcategory_list
from ..controller.filter import get_level_0_category
from ..controller.filter import get_level_1_category
from ..controller.filter import get_level_2_category
from ..controller.filter import get_proc_year
from ..controller.filter import get_filter_proc_level0
from ..controller.filter import get_filter_proc_level1
from ..controller.filter import get_filter_proc_level2
from ..controller.filter import get_filter_proc_year
from ..models.DefraData import DefraData
from ..models.Procurement import ProcurementData
from flask import jsonify, request 


    

filter_routes = Blueprint('filter_routes', __name__,
                        template_folder='templates',
                        static_folder='../public',
                        static_url_path='/public')




@filter_routes.route('/mapping/filter/defra/rows_avail')#if defra is loaded or not 
def is_defra_available():
    res = list(DefraData.query.filter().all())
    if len(res) == 0:
        return jsonify({"status": False,"n_rows": len(res)})
    else:
        return jsonify({"status": True,"n_rows": len(res)})



@filter_routes.route('/mapping/filter/proc/rows_avail')#show data in all the screens 
def no_of_rows():
    res = list(ProcurementData.query.filter().all())
    return jsonify({"status": True,"n_rows": len(res)})


#filters used from controllers for 3rd screen and 4th screen 



@filter_routes.route('/mapping/filter/suppliers')
def filter_data1():
   return jsonify(get_suppliers_list())


@filter_routes.route('/mapping/filter/level0', methods=["POST"])
def filter_level0():
    return jsonify(get_level_0_category(request.form.getlist('data[]')))


@filter_routes.route('/mapping/filter/level1', methods=["POST"])
def filter_level1():
    supplier_data = request.form.getlist('supplierData[]')
    level_0_data = request.form.getlist('level0Data[]')
    return jsonify(get_level_1_category(supplier_data, level_0_data))


@filter_routes.route('/mapping/filter/level2', methods=["POST"])
def filter_level2():
    supplier_data = request.form.getlist('supplierData[]')
    level_0_data = request.form.getlist('level0Data[]')
    level_1_data = request.form.getlist('level1Data[]')
    return jsonify(get_level_2_category(supplier_data, level_0_data, level_1_data))


@filter_routes.route('/mapping/filter/year', methods=["POST"])
def filter_proc_year():
    supplier_data = request.form.getlist('supplierData[]')
    level_0_data = request.form.getlist('level0Data[]')
    level_1_data = request.form.getlist('level1Data[]')
    level_2_data = request.form.getlist('level2Data[]')
    return jsonify(get_proc_year(supplier_data, level_0_data, level_1_data, level_2_data))


@filter_routes.route('/mapping/filter/efcategory')
def filter_efcategory():
    return jsonify(get_efcategory_list())


@filter_routes.route('/mapping/filter/proc/level0')
def filter_proc_level0():
    return jsonify(get_filter_proc_level0())


@filter_routes.route('/mapping/filter/proc/level1', methods=["POST"])
def filter_proc_level1():
    level_0_data = request.form.getlist('level0Data[]')
    return jsonify(get_filter_proc_level1(level_0_data))


@filter_routes.route('/mapping/filter/proc/level2', methods=["POST"])
def filter_proc_level2():
    level_0_data = request.form.getlist('level0Data[]')
    level_1_data = request.form.getlist('level1Data[]')
    return jsonify(get_filter_proc_level2(level_0_data, level_1_data))


@filter_routes.route('/mapping/filter/proc/year', methods=["POST"])
def filter_proc_year2():
    level_0_data = request.form.getlist('level0Data[]')
    level_1_data = request.form.getlist('level1Data[]')
    level_2_data = request.form.getlist('level2Data[]')
    return jsonify(get_filter_proc_year(level_0_data, level_1_data, level_2_data))


    
