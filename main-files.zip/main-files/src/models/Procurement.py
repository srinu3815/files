from flask import flash
from werkzeug.exceptions import HTTPException
from numpy import ogrid
from sqlalchemy.orm.session import Session
from ..db import db
from sqlalchemy.orm import sessionmaker

#accepted table properties for proc data
class ProcurementData(db.Model):
    __tablename__ = 'ProcurementData'
    __table_args__ = {'extend_existing': True}
    id = db.Column(db.Integer, primary_key=True)
    vendor_name = db.Column(db.String(225) )
    region = db.Column(db.String(64))
    country = db.Column(db.String(64))
    level_0_category = db.Column(db.String(128))
    level_1_category = db.Column(db.String(128))
    level_2_category = db.Column(db.String(128))
    spent_in_euro = db.Column(db.Float)
    year = db.Column(db.Float)
    ef_category = db.Column(db.String(512))
    ef_value = db.Column(db.Float)

    @staticmethod
    def create_object(data_dict):
        return ProcurementData(vendor_name = data_dict["vendor name level 1"],
                        region = data_dict["region"],
                        country = data_dict["country"],
                        level_0_category = data_dict["level 0 category"],
                        level_1_category = data_dict["level 1 category"],
                        level_2_category = data_dict["level 2 category"],
                        spent_in_euro = data_dict["spent in euro"],
                        year = data_dict["year"],
                        )

    @classmethod#save proc data to db 
    def save_data_to_table(cls, input_df):
        engine = db.get_engine()
        Session = sessionmaker(bind=engine)
        session = Session()
        try:
            data = [ProcurementData.create_object(i) for i in input_df.to_dict(orient='records')]
            print("Data length",len(data))
            session.add_all(data)
            session.commit()
            session.close()
            flash("Data upload successful. {} rows effected.".format(len(data)), "isa_success")
        except Exception as e:
            session.rollback()
            session.close()
            flash("Error uploading to database", "isa_error")
            print(e)
            raise HTTPException
            