/* browse button */
$(document).ready(function() {
    $('.btn').on('click', function() {
      $('.file').trigger('click');
    });
    $('.file').on('change', function() {
      var fileName = $(this)[0].files[0].name;    
      $('#file-name').val(fileName);
    });
    $(".download-mapping-file").click((e) => {
      window.open("/mapping/download");
    });
    $.get('/mapping/filter/proc/rows_avail', function (data, status) {
      $("#proc_no_rows").text(data.n_rows);
    })
    $.get('/mapping/filter/defra/rows_avail', function (data, status) {
      $("#defra_no_rows").text(data.n_rows);
    });
  });