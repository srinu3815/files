from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from .routes.routes import app_routes
from .routes.mapping_routes import mapping_routes
from .routes.upload_routes import upload_routes
from .routes.filter_routes import filter_routes

from .db import db


def create_app():
    app = Flask(__name__)
    app.config.from_pyfile('../config.py')

    db.init_app(app)#db

    # Import models
    from .models.Procurement import ProcurementData
    from .models.DefraData import DefraData


    with app.app_context():#models 
        db.create_all()
        db.session.commit()

    # Connect routes
    app.register_blueprint(upload_routes)#conotrollers(helpers,models) and  routes(controllers)
    app.register_blueprint(mapping_routes)
    app.register_blueprint(app_routes)
    app.register_blueprint(filter_routes)

    return app


APP = create_app()
